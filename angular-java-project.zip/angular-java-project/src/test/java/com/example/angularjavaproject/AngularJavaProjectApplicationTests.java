package com.example.angularjavaproject;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AngularJavaProjectApplicationTests {

	@Test
	void contextLoads() {
	}

}
